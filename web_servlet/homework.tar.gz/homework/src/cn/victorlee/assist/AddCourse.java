package cn.victorlee.assist;


public class AddCourse {

	public static void main(String[] args) {
		/*Course cs = null;
		cs.setCicos_id("2017213143001");
		cs.setCourse_name("");*/
	}

}
